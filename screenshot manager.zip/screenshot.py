from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
import pyautogui as pt
from ui import main
import os, playsound, random

class Capture(main.Ui_MainWindow, QMainWindow):
    resized = pyqtSignal(int, int)
    def __init__(self):
        super(Capture,self).__init__()
        self.setupUi(self)
        pt.FAILSAFE = False

        self.imageCaptured = ""
        self.images = []
        self.currentImageIndex = 0

        self.dtime = 0
        self.totalFiles = 1
        self.dirName = ""
        self.delay.setMinimum(0)
        self.delay.setMaximum(60)
        self.countFile.setMinimum(1)
        self.countFile.setMaximum(1000)
        self.filename.returnPressed.connect(self.capture_action)
        self.capture.clicked.connect(self.capture_action)
        self.delay.valueChanged.connect(self.timer)
        self.countFile.valueChanged.connect(self.files)
        self.path.clicked.connect(self.askDir)
        self.image.setMinimumSize(1,1)
        self.previous.clicked.connect(self.previous_next)
        self.next.clicked.connect(self.previous_next)

        icon = QIcon()
        icon.addPixmap(QPixmap("image/pfolder.png"), QIcon.Normal, QIcon.Off)
        self.path.setIcon(icon)

        icon1 = QIcon()
        icon1.addPixmap(QPixmap("image/pcamera.png"), QIcon.Normal, QIcon.Off)
        self.capture.setIcon(icon1)
        self.resized.connect(self.ifResized)
        
        

    def resizeEvent(self, event):
        wid = self.width()-80
        hit = self.height()-160
        self.resized.emit(wid, hit)
        return super(Capture, self).resizeEvent(event)

    def ifResized(self, wid, hit):
        try:
            self.pixmap = QPixmap(self.imageCaptured).scaled(wid, hit, Qt.IgnoreAspectRatio, Qt.SmoothTransformation)#Qt.KeepAspectRatioByExpanding
            self.image.setPixmap(self.pixmap)
            self.image.resize(wid, hit)
        except:
            pass

    def previous_next(self):
        obj = self.sender().objectName()
        wid = self.width()-80
        hit = self.height()-140
        try:
            if obj == "previous":
                if self.currentImageIndex > 0:
                    self.currentImageIndex -= 1
                    self.imageCaptured = self.images[self.currentImageIndex]
                    self.cimage.setText(" Current Image :  {}".format(self.imageCaptured))
                    self.pixmap = QPixmap(self.imageCaptured).scaled(wid, hit, Qt.IgnoreAspectRatio, Qt.SmoothTransformation)#Qt.KeepAspectRatioByExpanding
                    self.image.setPixmap(self.pixmap)
                    self.image.resize(wid, hit)
                    
            if obj == "next":
                if self.currentImageIndex < len(self.images)-1:
                    self.currentImageIndex += 1
                    self.imageCaptured = self.images[self.currentImageIndex]
                    self.cimage.setText(" Current Image :  {}".format(self.imageCaptured))
                    self.pixmap = QPixmap(self.imageCaptured).scaled(wid, hit, Qt.IgnoreAspectRatio, Qt.SmoothTransformation)#Qt.KeepAspectRatioByExpanding
                    self.image.setPixmap(self.pixmap)
                    self.image.resize(wid, hit)
        except Exception as ex:
            print(ex)
        
    
    def capture_action(self):
        self.hide()
        if self.dirName == "":
            self.askDir()
        fname = self.filename.text()
        files = []
        if fname.strip(" ")=="":
            
            name = "screenshot.jpg"
            if os.path.exists(self.dirName+"/"+name):
                i = 0
                j = 1
                while i<self.totalFiles:
                    name = self.dirName+"/"+"screenshot"+str(j)+".jpg"
                    if os.path.exists(name):
                        j+=1
                    else:
                        files.append(name)
                        j+=1
                        i+=1
                
            else:
               i = 0
               j = 1
               files.append(self.dirName+"/"+name)
               while i<self.totalFiles-1:
                    name = self.dirName+"/screenshot"+str(j)+".jpg"
                    if os.path.exists(name):
                        j+=1
                    else:
                        files.append(name)
                        j+=1
                        i+=1
        else:
            i = 0
            j = 1
            if os.path.exists(self.dirName+"/"+fname+".jpg"):
                while i<self.totalFiles:
                    name = self.dirName+"/"+fname.strip(" ")+str(j)+".jpg"
                    if os.path.exists(name):
                        j+=1
                    else:
                        files.append(name)
                        j+=1
                        i+=1
            else:
                files.append(self.dirName+"/"+fname+".jpg")
                while i<self.totalFiles-1:
                    name = self.dirName+"/"+fname.strip(" ")+str(j)+".jpg"
                    if os.path.exists(name):
                        j+=1
                    else:
                        files.append(name)
                        j+=1
                        i+=1

        sounds = ["sounds/capture.mp3", "sounds/capture1.mp3"]
        if self.isHidden():
            for file in files:
                pt.sleep(self.dtime)
                pt.screenshot(file)
                if self.captureSound.isChecked():
                    sound = random.choice(sounds)
                    playsound.playsound(sound)
                else:
                    pass
        try:
            for file in files:
                self.images.append(file)
            self.imageCaptured = files[0]
            self.currentImageIndex = 0
            self.cimage.setText(" Current Image :  {}".format(self.imageCaptured))
            wid = self.image.frameGeometry().width()
            hit = self.image.frameGeometry().height()
            self.pixmap = QPixmap(self.imageCaptured).scaled(wid, hit, Qt.IgnoreAspectRatio, Qt.SmoothTransformation)#,Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            self.image.setPixmap(self.pixmap)
            self.show()
        except Exception as ex:
            print(ex)
        
    def timer(self):
        self.dtime = self.delay.value()
        
    def files(self):
        self.totalFiles = self.countFile.value()

    def askDir(self):
        self.capture.setEnabled(True)
        self.dirName = QFileDialog.getExistingDirectory(self, "Select Directory")
        
        


if __name__ == "__main__":

    app = QApplication([])
    window = Capture()
    window.show()
    app.exec()
