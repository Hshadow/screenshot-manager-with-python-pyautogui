import subprocess

pyqt5 = ["pip", "install", "PyQt5"]
pyautogui = ["pip", "install", "pyautogui"]
playsound = ["pip", "install", "playsound"]

### install PyQt5 gui package
print("{}".format(" ".join(pyqt5)), end="\n")
out = subprocess.check_output(pyqt5, shell = True)
print(out.decode(), end = "\n\n")

### install pyautogui gui automation module
print("{}".format(" ".join(pyautogui)), end="\n")
out = subprocess.check_output(pyautogui, shell = True)
print(out.decode(), end = "\n\n")

### install playsound sound playing module
print("{}".format(" ".join(playsound)), end="\n")
out = subprocess.check_output(playsound, shell = True)
print(out.decode(), end = "\n\n")
